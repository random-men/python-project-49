# import random

print('Answer "yes" if the nubmer is even, otherwise answer "no"')
