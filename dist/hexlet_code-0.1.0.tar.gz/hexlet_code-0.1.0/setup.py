# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prog = brain_games.scripts.brain_prog:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\nBadges:\n\n[![Actions Status](https://github.com/random-men/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/random-men/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/0163c62caee654b5962e/maintainability)](https://codeclimate.com/github/random-men/python-project-49/maintainability)\n\nDemos:\n[![asciicast](https://asciinema.org/a/Snc1GhgdCLxyt10MmxhMV806J.svg)](https://asciinema.org/a/Snc1GhgdCLxyt10MmxhMV806J)\n[![asciicast](https://asciinema.org/a/Z9siri10rz4slMOM65DEC4b0X.svg)](https://asciinema.org/a/Z9siri10rz4slMOM65DEC4b0X)\n[![asciicast](https://asciinema.org/a/l0f3LblOBpPXtdrUpUN1p0bDN.svg)](https://asciinema.org/a/l0f3LblOBpPXtdrUpUN1p0bDN)',
    'author': 'Ruslan M',
    'author_email': 'evilpingu@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
