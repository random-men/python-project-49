### Hexlet tests and linter status:
Badges:

[![Actions Status](https://github.com/random-men/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/random-men/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0163c62caee654b5962e/maintainability)](https://codeclimate.com/github/random-men/python-project-49/maintainability)

Demos:
[![asciicast](https://asciinema.org/a/Snc1GhgdCLxyt10MmxhMV806J.svg)](https://asciinema.org/a/Snc1GhgdCLxyt10MmxhMV806J)
[![asciicast](https://asciinema.org/a/Z9siri10rz4slMOM65DEC4b0X.svg)](https://asciinema.org/a/Z9siri10rz4slMOM65DEC4b0X)
[![asciicast](https://asciinema.org/a/l0f3LblOBpPXtdrUpUN1p0bDN.svg)](https://asciinema.org/a/l0f3LblOBpPXtdrUpUN1p0bDN)
[![asciicast](https://asciinema.org/a/XlAOrme9w4W8WVhUxp5dDCEwD.svg)](https://asciinema.org/a/XlAOrme9w4W8WVhUxp5dDCEwD)