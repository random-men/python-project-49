### Hexlet tests and linter status:
[![Actions Status](https://github.com/random-men/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/random-men/python-project-49/actions)<br>
<a href="https://codeclimate.com/github/random-men/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0163c62caee654b5962e/maintainability" /></a><br>
<a href="https://asciinema.org/a/rNuCKqqwatk4dIXzANgDR875S" target="_blank"><img src="https://asciinema.org/a/rNuCKqqwatk4dIXzANgDR875S.svg" /></a>
