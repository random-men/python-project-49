### Hexlet tests and linter status:
[![Actions Status](https://github.com/random-men/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/random-men/python-project-49/actions)
<a href="https://codeclimate.com/github/random-men/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0163c62caee654b5962e/maintainability" /></a>
